Canvas Single Tab Monitor (prototype)

1. Extract this ZIP.
2. Open Chrome: chrome://extensions
3. Enable Developer mode; choose Load unpacked.
4. Select the extracted chrome_single_tab_monitor folder.
5. Close all extra tabs/windows and open the Canvas exam.
6. Click the extension icon, then Start.
7. The extension flags additional tabs/windows in this Chrome profile and active pages not recognized as Canvas.
8. Click Stop and Export CSV when finished.

LIMITATIONS: This tool does not prevent opening tabs; it only detects and logs them. It cannot monitor other Chrome profiles, other browsers, devices, or incognito tabs unless separately enabled. Students can disable it or alter locally stored logs. Canvas URL detection is heuristic and may flag SSO or external tools. Reports stay local until manually exported. Inform students about monitoring and obtain institutional approval before deployment on personal devices. Use approved lockdown software for enforceable restrictions.
